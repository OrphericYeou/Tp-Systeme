Exercice 4: 

1- reussir a faire communiquer le client et le serveur; envoyer des fichiers

2- J'	i realiser la connection à l'aide d'un socket et de differentes fonctions et jai utiliser une fonction pour allouer la memoire pour le fichier à envoyer

3-voir code
