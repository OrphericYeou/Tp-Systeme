#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>

//Fonction affichant le numéro du fils et son  PID
void fils (int i)
{
    printf ("Processus numero: %i Le PID est : %i \n", i, getpid());
    exit(0);
}

int main ()
{

int i;
//Creation et affichage des pid des trois fils
for (i=1; i<4; i++) {
if(fork()== 0) {
printf ("creation du Processus: ", i);
fils(i);
exit(0);
}
}
sleep(2);
//printf ("Voila un dernier message \n" );
return (0);
}

