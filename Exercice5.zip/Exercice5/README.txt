Exercice 5: 

1- l'envoi d'une requete à un serveur de facon cyclique

2-

3- Voir code
