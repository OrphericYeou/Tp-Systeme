Exercice 3: 

1- allouer en memoire un espace pour chaque chiffre de la matrice

2-j'ai utilise une fonction pour attacher les chiffres a la memoire

3- Voir Code
