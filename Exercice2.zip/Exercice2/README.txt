Exercice 2: 

1- La valeur finale dans la memoire partagee est inferieure ou egale a 300.

2-Pour resoudre le probleme il faut que chaque processus attende son tour pour operer

3-Voir programme.
